import connexion
import six

from swagger_server import util


def questions_get(sortByUpvotes=None):  # noqa: E501
    """Get a list of all questions

     # noqa: E501

    :param sortByUpvotes: Sort the questions by upvotes
    :type sortByUpvotes: bool

    :rtype: None
    """
    return 'do some magic!'


def questions_post(body, title, tags):  # noqa: E501
    """Create a new question

     # noqa: E501

    :param body: Question object that needs to be created
    :type body: dict | bytes
    :param title: Question object that needs to be created
    :type title: dict | bytes
    :param tags: Question object that needs to be created
    :type tags: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        body = .from_dict(connexion.request.get_json())  # noqa: E501
    if connexion.request.is_json:
        title = .from_dict(connexion.request.get_json())  # noqa: E501
    if connexion.request.is_json:
        tags = .from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def questions_question_id_delete(questionId):  # noqa: E501
    """Delete a question by ID

     # noqa: E501

    :param questionId: ID of question to get details for
    :type questionId: int

    :rtype: None
    """
    return 'do some magic!'


def questions_question_id_get(questionId):  # noqa: E501
    """Get details of a specific question by ID

     # noqa: E501

    :param questionId: ID of question to get details for
    :type questionId: int

    :rtype: None
    """
    return 'do some magic!'


def questions_question_id_put(questionId, body=None, title=None, tags=None):  # noqa: E501
    """Update an existing question

     # noqa: E501

    :param questionId: ID of question to get details for
    :type questionId: int
    :param body: Question object that needs to be created
    :type body: dict | bytes
    :param title: Question object that needs to be created
    :type title: dict | bytes
    :param tags: Question object that needs to be created
    :type tags: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        body = .from_dict(connexion.request.get_json())  # noqa: E501
    if connexion.request.is_json:
        title = .from_dict(connexion.request.get_json())  # noqa: E501
    if connexion.request.is_json:
        tags = .from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'
