import connexion
import six

from swagger_server.models.answer import Answer  # noqa: E501
from swagger_server import util


def questions_question_id_answers_answer_id_delete(questionId, answerId):  # noqa: E501
    """Delete an answer to a specific question by ID

     # noqa: E501

    :param questionId: ID of question to get answer for
    :type questionId: int
    :param answerId: ID of answer to get details for
    :type answerId: int

    :rtype: None
    """
    return 'do some magic!'


def questions_question_id_answers_answer_id_get(questionId, answerId):  # noqa: E501
    """Get details of a specific answer to a specific question by ID

     # noqa: E501

    :param questionId: ID of question to get answer for
    :type questionId: int
    :param answerId: ID of answer to get details for
    :type answerId: int

    :rtype: Answer
    """
    return 'do some magic!'


def questions_question_id_answers_answer_id_put(questionId, answerId, body=None):  # noqa: E501
    """Update an existing answer to a specific question

     # noqa: E501

    :param questionId: ID of question to get answer for
    :type questionId: int
    :param answerId: ID of answer to get details for
    :type answerId: int
    :param body: update answer to that question
    :type body: dict | bytes

    :rtype: Answer
    """
    if connexion.request.is_json:
        body = .from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def questions_question_id_answers_get(questionId, sortByUpvotes=None):  # noqa: E501
    """Get a list of all answers to a specific question by ID

     # noqa: E501

    :param questionId: ID of question to get answers for
    :type questionId: int
    :param sortByUpvotes: Sort the questions by upvotes
    :type sortByUpvotes: bool

    :rtype: Answer
    """
    return 'do some magic!'


def questions_question_id_answers_post(questionId, body=None):  # noqa: E501
    """Post a new answer to a specific question

     # noqa: E501

    :param questionId: ID of question to get answers for
    :type questionId: int
    :param body: Question object that needs to be created
    :type body: dict | bytes

    :rtype: Answer
    """
    if connexion.request.is_json:
        body = .from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'
