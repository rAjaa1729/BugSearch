import connexion
import six

from swagger_server.models.comment import Comment  # noqa: E501
from swagger_server import util


def questions_question_id_answers_answer_id_comments_comment_id_delete(questionId, answerId, commentId):  # noqa: E501
    """Delete a comment by comment ID

     # noqa: E501

    :param questionId: ID of question to get answer for
    :type questionId: int
    :param answerId: ID of answer to get details for
    :type answerId: int
    :param commentId: ID of the comment to get details for
    :type commentId: int

    :rtype: None
    """
    return 'do some magic!'


def questions_question_id_answers_answer_id_comments_comment_id_get(questionId, answerId, commentId):  # noqa: E501
    """Get all comments on an answer

     # noqa: E501

    :param questionId: ID of question to get answer for
    :type questionId: int
    :param answerId: ID of answer to get details for
    :type answerId: int
    :param commentId: ID of the comment to get details for
    :type commentId: int

    :rtype: Comment
    """
    return 'do some magic!'


def questions_question_id_answers_answer_id_comments_comment_id_put(questionId, answerId, commentId, body=None):  # noqa: E501
    """Update a comment by comment ID

     # noqa: E501

    :param questionId: ID of question to get answer for
    :type questionId: int
    :param answerId: ID of answer to get details for
    :type answerId: int
    :param commentId: ID of the comment to get details for
    :type commentId: int
    :param body: 
    :type body: dict | bytes

    :rtype: Comment
    """
    if connexion.request.is_json:
        body = .from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def questions_question_id_answers_answer_id_comments_get(questionId, answerId):  # noqa: E501
    """Get all comments on an answer

     # noqa: E501

    :param questionId: ID of question to get answer for
    :type questionId: int
    :param answerId: ID of answer to get details for
    :type answerId: int

    :rtype: Comment
    """
    return 'do some magic!'


def questions_question_id_comments_comment_id_delete(questionId, commentId):  # noqa: E501
    """Delete a comment by comment ID

     # noqa: E501

    :param questionId: ID of the question to which the comment belongs
    :type questionId: int
    :param commentId: ID of the comment to get details for
    :type commentId: int

    :rtype: None
    """
    return 'do some magic!'


def questions_question_id_comments_comment_id_get(questionId, commentId):  # noqa: E501
    """Get a comment by comment ID

     # noqa: E501

    :param questionId: ID of the question to which the comment belongs
    :type questionId: int
    :param commentId: ID of the comment to get details for
    :type commentId: int

    :rtype: Comment
    """
    return 'do some magic!'


def questions_question_id_comments_comment_id_put(questionId, commentId, body):  # noqa: E501
    """Update a comment by comment ID

     # noqa: E501

    :param questionId: ID of the question to which the comment belongs
    :type questionId: int
    :param commentId: ID of the comment to get details for
    :type commentId: int
    :param body: Comment object that needs to be updated
    :type body: str

    :rtype: None
    """
    return 'do some magic!'


def questions_question_id_comments_post(questionId):  # noqa: E501
    """Post a new comment on a question

     # noqa: E501

    :param questionId: ID of the question to comment on
    :type questionId: int

    :rtype: Comment
    """
    return 'do some magic!'
